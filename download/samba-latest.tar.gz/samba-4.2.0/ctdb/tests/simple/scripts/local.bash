if [ -n "$TEST_LOCAL_DAEMONS" ] ; then
    . "${TEST_SUBDIR}/scripts/local_daemons.bash"
fi
